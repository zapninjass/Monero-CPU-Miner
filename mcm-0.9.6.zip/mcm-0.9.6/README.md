# MCM

MCM is Monero (XMR) CPU miner with the best performance.
Originally based on xmrig (net and config) with completely rewritten algo from scratch on ASM.
On SSE4 (non AES-NI) cpu performance boost up to 50%.

## Index
* [Features](#features)
* [Download](#download)
* [Options](#options)
* [CPU mining performance](#cpu-mining-performance)
* [Maximum performance checklist](#maximum-performance-checklist)

## Features
* The best performance.
* SSE4 (non AES-NI) cpu performance boost up to 50%.
* CryptoNight v7 and v8.
* CryptoNight-Lite.
* CryptoNight-Heavy.
* Small Windows executable, without dependencies.
* Official Windows support.
* Support for backup (failover) mining server.
* Keepalived support.
* SSL/TLS support for secure connections to pools.
* Command line options compatible with cpuminer & xmrig.
* Smart automatic [CPU configuration]
* Nicehash support
* Low fee 1%.

## Download
* Binary releases: https://github.com/alex-tk/mcm/releases

## Options
```
-a, --algo=ALGO          specify the algorithm to use
                             cryptonight
                             cryptonight-lite
                             cryptonight-heavy
                             cryptonight-turtle
  -o, --url=URL            URL of mining server
  -O, --userpass=U:P       username:password pair for mining server
  -u, --user=USERNAME      username for mining server
  -p, --pass=PASSWORD      password for mining server
      --rig-id=ID          rig identifier for pool-side statistics (needs pool support)
  -t, --threads=N          number of miner threads
  -v, --av=N               algorithm variation, 0 auto select
  -k, --keepalive          send keepalived packet for prevent timeout (needs pool support)
      --nicehash           enable nicehash.com support
      --tls                enable SSL/TLS support (needs pool support)
      --tls-fingerprint=F  pool TLS certificate fingerprint, if set enable strict certificate pinning
  -r, --retries=N          number of times to retry before switch to backup server (default: 5)
  -R, --retry-pause=N      time to pause between retries (default: 5)
      --cpu-affinity       set process affinity to CPU core(s), mask 0x3 for cores 0 and 1
      --cpu-priority       set process priority (0 idle, 2 normal to 5 highest)
      --no-huge-pages      disable huge pages support
      --no-color           disable colored output
      --variant            algorithm PoW variant
      --user-agent         set custom user-agent string for pool
  -B, --background         run the miner in the background
  -c, --config=FILE        load a JSON-format configuration file
  -l, --log-file=FILE      log all output to a file
  -S, --syslog             use system log for output messages
      --max-cpu-usage=N    maximum CPU usage for automatic threads mode (default 75)
      --safe               safe adjust threads and av settings for current CPU
      --asm=ASM            ASM code for cn/2, possible values: auto, none, intel, ryzen.
      --api-port=N         port for the miner API
      --api-access-token=T access token for API
      --api-worker-id=ID   custom worker-id for API
      --api-id=ID          custom instance ID for API
      --api-ipv6           enable IPv6 support for API
      --api-no-restricted  enable full remote access (only if API token set)
      --dry-run            test configuration and exit
  -h, --help               display this help and exit
  -V, --version            output version information and exit
```

Also you can use configuration via config file, default **config.json**. You can load multiple config files and combine it with command line options.

### Algorithm variations
* `--av=0` Auto.
* `--av=1` For CPUs with hardware AES.
* `--av=2` Lower power mode (double hash).
* `--av=3` Software AES implementation.
* `--av=4` Software AES double hash mode implementation.

## CPU mining performance

### Core2 Quad Q9300 2.5 GHz 6M, 4 threads, 64-bits, Software AES implementation
algo | cn/r | cn/1 | cn/msr | cn/rto | cn/xtl | cn/xao | cn/2 | cn-lite/1 | cn-trtl
----------- | ---- | ---- | ------ | ------ | ------ | ------ | ---- | ---------- | ----------
mcm 0.9.6   |  60 |  114 |    132 |     96 |     96 |     50 |   84 |       234 |       760
xmrig 2.13.1 |  54 |   73 |     89 |     64 |     64 |     42 |   50 |       158 |       476

Please note performance is highly dependent on system load. The numbers above are obtained on an idle system. Tasks heavily using a processor cache, such as video playback, can greatly degrade hashrate. Optimal number of threads depends on the size of the L3 cache of a processor, 1 thread requires 2 MB of cache.

## Maximum performance checklist
* Idle operating system.
* Do not exceed optimal thread count.
* Use modern CPUs with AES-NI instruction set.
* Try setup optimal cpu affinity.
* Enable fast memory (Large/Huge pages, reboot) (To enable huge pages on Windows: https://msdn.microsoft.com/en-gb/library/ms190730.aspx, Linux: sudo sysctl -w vm.nr_hugepages=128).
