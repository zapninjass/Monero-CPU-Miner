# v0.9.6
- added support for new algorithm cryptonight/r, short alias cn/r (also known as CryptoNightR or CryptoNight variant 4), for upcoming Monero fork

# v0.9.5
- added new algorithm cn-pico/trtl (aliases cryptonight-turtle, cn-trtl) for TurtleCoin (TRTL) fork.
- added new algorithm cn/half for Masari and Stellite forks.

# v0.9.4
- +20% for cn/2 (CryptoNight variant 2 for Monero fork) --av=3 (Software AES implementation).

# v0.9.3
- performance boost for CryptoNight variant 2 for Monero fork --av=3 (Software AES implementation).
- based on xmrig 2.8.3

# v0.9.2
- added new algorithm CryptoNight variant 2 for Monero fork
- added CryptoNight-Lite and CryptoNight-Heavy support.
- added SSL/TLS support for secure connections to pools
- based on xmrig 2.8.1 (https://github.com/xmrig/xmrig/blob/master/README.md)

# v0.9.1
- performance boost for --av=0 (Software AES implementation).

# v0.9.0
- Initial public release.